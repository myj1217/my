package com.springex.mapper;

public interface TimeMapper2 {
    String getNow();
}
